
import java.awt.*;

interface HotSpotListener 
{
	void hotSpotEvent(HotSpot hs);
}